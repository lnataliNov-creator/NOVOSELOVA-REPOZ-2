import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://www.yakaboo.ua/ua/ja-bachu-vas-cikavit-pit-ma.html")
String pageTitle = selenium.getText("xpath=//*[@id=\"product-title\"]/span[2]")
selenium.click("xpath=//*[@id=\"product\"]/div[1]/div/div/section[1]/div[4]/div[4]/button")
println(pageTitle)
softAssertion.assertEquals(selenium.isElementPresent("xpath=//*[@id=\"site-header\"]/div/div/div[3]/button/span"), true)
selenium.click("xpath=//*[@id=\"site-header\"]/div/div/div[3]/button/div")
softAssertion.assertEquals(pageTitle, selenium.getText("xpath=//*[@id=\"viewport\"]/div[2]/div/ul/div[1]/div/div/div/div[1]/a"))
softAssertion.assertEquals("1", selenium.getValue("//*[@id=\"viewport\"]/div[2]/div/ul/div[1]/div/div/div/div[2]/div/div[2]/div/div/input"))
String bookPrice = selenium.getText("//*[@id=\"viewport\"]/div[2]/div/ul/div[1]/div/div/div/div[1]/div[1]/div/div/span")
println(bookPrice)
selenium.click("//*[@id=\"viewport\"]/div[2]/div/div[2]/span[2]")
