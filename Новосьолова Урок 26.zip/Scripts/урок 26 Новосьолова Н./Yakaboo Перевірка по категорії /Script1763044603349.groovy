import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
String url = "https://www.yakaboo.ua/"
selenium.open(url)
String mainCategoryPaperBooks = "//*[@id=\"home\"]/div/div[1]/section/div/div[2]/button[1]/span"
selenium.click(mainCategoryPaperBooks)
String subCategoryChildLit = "//*[@id=\"viewport\"]/div[3]/section/div[2]/div[1]/div[9]/a"
selenium.click(subCategoryChildLit)
String subSubCategoryAdventure = "//*[@id=\"viewport\"]/div[8]/div[1]/div[2]/div/div[2]/div/div[1]/div/a/span"
selenium.click(subSubCategoryAdventure)
String categoryTitleCSS = "//*[@id=\"viewport\"]/div[8]/div[1]/div[1]/div[2]/div/h1"
softAssertion.assertEquals("@83>4=8FL:V @><0=8 4;O 4VB59", selenium.getText(categoryTitleCSS))
selenium.click("xpath=//*[@id=\"1381752\"]/div[3]/div[1]/div[2]/a")
/* selenium.verifyText ("//*[@id=\"product\"]/div[1]/div/div/section[2]/div[4]/div/div/a[1]/span", "@83>4=8FL:V @><0=8 4;O 4VB59") */
