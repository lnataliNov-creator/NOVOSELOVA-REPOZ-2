<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>урок 26 Новосьолова Н.</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>2c6907d5-e181-46fe-aaba-372536a4398c</testSuiteGuid>
   <testCaseLink>
      <guid>06706ab4-ef31-4263-b684-db1ec9b172e2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/урок 26 Новосьолова Н./Yakaboo додавання товару в кошик</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>c449da06-52f3-4c42-945e-bb130d8de71c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/урок 26 Новосьолова Н./перевірка поля"Пошук" за ключовими словами</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e035482b-bda3-4541-8299-f1f30f88e5c4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/урок 26 Новосьолова Н./Yakaboo Перевірка по категорії </testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    